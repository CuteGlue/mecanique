#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

using namespace std;
const int N = 15 ;


void Chesseboard(int table[N][N]) ;
void resultat(int win, string nameP1, string nameP2) ;
void PlayChess(int table[N][N], string playerName) ;
int Check_Board(int table[N][N], int x, int y) ;
int countChess(int table[N][N], int x, int y, int dx, int dy);
bool getFive(int table[N][N], int x, int y, int dx, int dy) ;

int main()
{
    int table[N][N]  = {};
    int win = 0 ;
    int currentPlayer = 0 ;

    string playerName ;
    string nameP1, nameP2 ;
    cout << " Enter first player's name  :  " ;
    cin >> nameP1 ;
    cout << " Enter second player's name :  ";
    cin >> nameP2 ;

    do
    {
       Chesseboard(table) ;

       if (currentPlayer == 0){
         playerName = nameP1 ;
       }
       else{
        playerName = nameP2 ;
       }
       cout<<endl ;
       cout << playerName << " , it's your turn ! enter your position :  " ;
       bool canPlace = true ;
       int x, y ;
       do
       {
           if (canPlace == false)
           {
               cout << playerName << " , error ! please take another position :  " ;
           }
           char first ;
           int second ;
           cin >> first >>second ;
           y = first-(int)'A';
           x = second-1;
           canPlace = true ;
           canPlace = (canPlace && x<=N && x>=0) ;
           canPlace = (canPlace && y<=N && y>=0) ;
           canPlace = (canPlace && table[y][x]==0) ;

       }while(canPlace == false) ;

       table[y][x] = currentPlayer + 1 ;

       currentPlayer++ ;
       currentPlayer %= 2 ;
       win = Check_Board(table,x,y) ;

    }while(win==0) ;

    Chesseboard(table) ;
    resultat(win, nameP1, nameP2);

    return 0;
}

void Chesseboard(int table[N][N])
{
    cout<<endl ;
    cout << "   ";
    for (int i = 0;  i < N; i++)
    {
        if(i < 10){
            cout <<" "<< (i+1) << " " ;
        }
        else{
            cout << (i+1) << " " ;
        }
    }
    cout << endl ;
    for (int i = 0; i<N; i++)
    {
        cout <<" "<<(char)('A' + i) ;
        for (int j = 0; j < N; j++)
        {
            int value = table[i][j] ;
            char c = ' ' ;
            switch (value) {
				case 0:
					c = '.';
					break;
				case 1:
					c = 'x';
					break;
				case 2:
					c = 'o';
					break;
				}
            cout<<"  "<<c ;
        }
        cout<<endl ;
    }

}

void resultat(int win, string nameP1, string nameP2)
{
    if (win == 1)
        {
            cout<< " " <<nameP1<<" win !"<< endl ;
        }
        else if (win == 2)
        {
            cout<< " "<<nameP2<<" win !"<< endl ;
        }
        else
        {
            cout<< " "<< nameP1<< " and " << nameP2 <<" equal !"<<endl ;
        }
}

void PlayChess(int table[N][N],string playerName) {
    string first ;
    int second ;
    cin >> first >>second ;

}

int Check_Board(int table[N][N], int x, int y)
{
    bool false1 = getFive(table, x, y, 1, 0) ;
    bool false2 = getFive(table, x, y, 0, 1) ;
    bool false3 = getFive(table, x, y, 1, -1) ;
    bool false4 = getFive(table, x, y, 1, 1) ;
    if(false1 || false2 || false3 || false4)
    {
        return table[y][x] ;
    }
    return 0 ;
}


bool getFive(int table[N][N], int x, int y, int dx, int dy)
{
    int countNumber  = 0 ;
    countNumber += countChess(table,x,y,dx,dy) ;
    countNumber += countChess(table,x,y,-dx,-dy) ;
    countNumber -= 1 ;
    return countNumber>= 5 ;
}



int countChess(int table[N][N], int x, int y, int dx, int dy)
{
    int countNumber = 0 ;
    int valueOriginal = table[y][x] ;
    int value ;
    do
    {
        countNumber++ ;
        x += dx ;
        y += dy ;
        value = table[y][x] ;
        if (x<0 || y<0 || x>N-1 || y > N-1)
        {
            break ;
        }
    }while(value == valueOriginal) ;
    return countNumber ;
}















































